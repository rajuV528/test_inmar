﻿using Microsoft.AspNetCore.Mvc;
using ProductsAPI.Models;
using System.Collections.Generic;
using ProductsAPI.Services;
using System.Threading.Tasks;
using System.Linq;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ProductsAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OfferController : ControllerBase
    {
        IOfferService offerService;
        public OfferController(IOfferService _offerService)
        {
            offerService = _offerService;
        }
        // GET: api/<OfferController>
        [HttpGet("GetTodaysOffers")]
        public List<Offer>GetTodaysOffers()
        {
            //await Task.Run(() =>            {
            //    return offerService.GetTodaysOffers();
            //});
            return offerService.GetTodaysOffers();
        }

        // GET: api/<OfferController>
        [HttpGet("GetAllProducts")]
        public List<Product> GetAllProducts()
        {
            //await Task.Run(() => {
            //    return offerService.GetAllProducts().OrderBy(x => x.Price).Take(3);
            //});
            return offerService.GetAllProducts().OrderBy(x => x.Price).Take(3).ToList();
        }

        // GET: api/<OfferController>
        [HttpGet("GetSecondLowestProduct")]
        public List<Product> GetSecondLowestProduct()
        {
            //await Task.Run(() => {
            //    return offerService.GetAllProducts().OrderBy(x => x.Price).Skip(1).Take(1);
            //});
            return offerService.GetAllProducts().OrderBy(x => x.Price).Skip(1).Take(1).ToList();
        }

        // PUT api/<OfferController>/5
        [HttpPost]
        public void Addproduct(int id, [FromBody] Product value)
        {
            offerService.Addproduct(value);
        }

      
    }
}
