﻿using ProductsAPI.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ProductsAPI.Services
{
    public interface IOfferService
    {
        List<Product> GetAllProducts();
       List<Offer> GetTodaysOffers();
        void Addproduct(Product product);
    }
}
