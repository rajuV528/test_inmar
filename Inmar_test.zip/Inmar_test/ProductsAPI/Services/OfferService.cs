﻿using ProductsAPI.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;

namespace ProductsAPI.Services
{
    public class OfferService : IOfferService
    {
        private List<Product> Inventory;
        public OfferService()
        {
            CreateProducts();
        }
        private void CreateProducts()
        {
            Inventory = new List<Product>();
            Inventory.Add(new Product("P1", 1000, "P1 desc"));
            Inventory.Add(new Product("P2", 200, "P2 desc"));
            Inventory.Add(new Product("P3", 400, "P3 desc"));
            Inventory.Add(new Product("P4", 700, "P4 desc"));
            Inventory.Add(new Product("P5", 600, "P5 desc"));
            Inventory.Add(new Product("P6", 800, "P6 desc"));
        }
        public List<Product> GetAllProducts()
        {
            return Inventory;
        }

        public List<Offer> GetTodaysOffers()
        {
            var offers = new List<Offer>();
            offers.Add(new Offer("ComboPackage1", Inventory.Take(3).ToList()));
            offers.Add(new Offer("ComboPackage2", Inventory.Skip(1).Take(3).ToList()));
            offers.Add(new Offer("ComboPackage3", Inventory.Skip(2).Take(3).ToList()));
            offers.Add(new Offer("ComboPackage4", Inventory.Skip(3).Take(3).ToList()));
            return offers;
        }

        public void Addproduct(Product product)
        {
            Inventory.Add(product);
        }
    }
}
