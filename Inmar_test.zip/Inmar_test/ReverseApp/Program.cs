﻿using System;

namespace ReverseApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var name = Console.ReadLine();
            if (name.Length > 0)
            {
                for (int i = name.Length-1; i >=0; i--)
                {
                    Console.Write(name[i]);
                    

                }
                
            }
        }
    }
}
